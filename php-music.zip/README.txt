Convert your Youtube.com music links to mp3 files here:
http://youtubemp3.to/

Add album art here:
http://www.watermark-images.com/mp3-tag-editor-online.aspx
http://www.imgaid.com/mp3-tag-editor-online.aspx

Edit the music file here:
https://123apps.com/