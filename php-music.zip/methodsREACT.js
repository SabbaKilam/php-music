/*global L*/
/*global m*/
/*global v*/
/*global c*/
//============================//

/////////////////////////////////////////
c.setToggleButton = (o) => {
	m.buttonIsIn = !m.buttonIsIn;
	m.buttonIsIn && m.pressCount++;
	//--------------------------------//
};
c.showToggleButton = ({ counter, button }) => {
	m.buttonIsIn
		? button.setAttribute(`class`, `pressed`)
		: button.setAttribute(`class`, `released`);
	counter.innerText = m.pressCount;
};
////////////////////////////////////////
c.setRandomColor = (m)=>{
  const h = Math.floor(360*Math.random()) + 1;
  const s = Math.floor(100*Math.random()) + 1;
  const l = Math.floor(100*Math.random()) + 1;
  const a = Math.random().toFixed(2);
  m.randomColor = `hsla(${h}, ${s}%, ${l}%, ${a})`
  //--------------------------------//
}
c.showRandomColor = ({buttonHolder, button})=>{
  buttonHolder.styles(`background-color: ${m.randomColor}`)
  button.innerText = m.randomColor
}
//////////////////////////////////////////
c.setResize = (m) => {
  m.width = window.innerWidth
}
c.showResize = ({button})=>{
  m.width > m.MAX_WIDTH
  ? button.styles(`width: ${m.MAX_WIDTH}px`)
  : button.styles(`width: 93%`)
}
///////////////////////////////////////
c.showInfo = ({info}) => {
  const msg = `${m.id}: ${m.type}, prior event: ${m.priorType[1]}`
  //const msg = `${m.id}: ${m.type}, clicked?: ${m.clicked}`
  
  info.innerText = msg;
}
//////////////////////////////////////////
